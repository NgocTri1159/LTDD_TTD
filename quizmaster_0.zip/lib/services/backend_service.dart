
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:firebase_auth/firebase_auth.dart';

class BackendService {
  static const String baseUrl = 'http://localhost:3000';

  // Gửi Firebase ID Token đến Backend để cấp quyền
  static Future<void> provisionRole() async {
    final user = FirebaseAuth.instance.currentUser;

    if (user == null) {
      throw Exception('Người dùng chưa đăng nhập Firebase');
    }

    // 1. Lấy Firebase ID Token
    final idToken = await user.getIdToken();

    if (idToken == null || idToken.isEmpty) {
      throw Exception('Không lấy được Firebase ID Token');
    }

    // 2. Gọi API Backend
    final response = await http.post(
      Uri.parse('$baseUrl/auth/provision-role'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $idToken',
      },
    ).timeout(const Duration(seconds: 15));

    debugPrint('BACKEND STATUS: ${response.statusCode}');
    debugPrint('BACKEND RESPONSE: ${response.body}');

    final result = jsonDecode(response.body);

    if (response.statusCode != 200 || result['success'] != true) {
      throw Exception(
        result['message'] ?? 'Không thể cấp quyền tài khoản',
      );
    }

    // 3. Làm mới Firebase ID Token
    await user.getIdToken(true);

    // 4. Đọc lại Custom Claims từ token mới
    final tokenResult = await user.getIdTokenResult(true);

    debugPrint('========== KIEM TRA CUSTOM CLAIMS ==========');
    debugPrint('UID: ${user.uid}');
    debugPrint('CLAIMS: ${tokenResult.claims}');
    debugPrint('ROLE: ${tokenResult.claims?['role']}');
    debugPrint('============================================');

    // 5. Kiểm tra quyền
    if (tokenResult.claims?['role'] != 'authenticated') {
      throw Exception(
        'Tài khoản chưa nhận được quyền authenticated',
      );
    }

    debugPrint('CAP QUYEN THANH CONG!');
  }
}
